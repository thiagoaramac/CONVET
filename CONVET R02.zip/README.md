# CONVET
Gerador de Ranking do CONVET

O arquivo app.py é o arquivo principal e deverá ser executado.

por enquanto os seguintes imports são utilizados:

import dash
import polars
import os

Garanta que essas bibliotecas estão instaladas
